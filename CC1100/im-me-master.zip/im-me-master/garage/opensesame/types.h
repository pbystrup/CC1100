#define u8 unsigned char
#define u16 unsigned int
#define u32 unsigned long int
