#include "global.hpp"

namespace cc1110
{
bool trace = false;
bool logging = false;
bool debug = false;

FILE* logfile = nullptr;
}

