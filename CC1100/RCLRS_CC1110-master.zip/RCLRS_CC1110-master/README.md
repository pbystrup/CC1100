RC LRS Tx/Rx - 8ch with TI CC1110 32kb.

for this project I'm using 'CC1110+PA+LNA-470MHz' wireless module - Output power 18-23dbm, 
and get more that 12km of ground range.