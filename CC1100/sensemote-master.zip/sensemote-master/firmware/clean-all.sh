#!/bin/sh

make -C cctl/cctl-prog clean
make -C config clean

rm -rf obj

