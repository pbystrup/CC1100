#ifndef HEX_H
#define HEX_H 1

int read_hexfile(uint8_t *buf, size_t buflen, const char *filename);

#endif

