YARD Stick One, a sub-1 GHz wireless transceiver controlled by your computer

project home: http://greatscottgadgets.com/yardstickone/

designed by Michael Ossmann <mike@ossmann.com>
