//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DebugWindow.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ImageScope"
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner): TForm(Owner)
{
}
//---------------------------------------------------------------------------
