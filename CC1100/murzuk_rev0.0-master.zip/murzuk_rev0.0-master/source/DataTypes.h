#ifndef DATA_TYPES_H
#define DATA_TYPES_H

typedef unsigned char uint8;

#endif
