#ifndef CC1111USB_H
#define CC1111USB_H

#include "chipcon_usb.h"

#endif
