

//! Find the length of a string.
u16 strlen(char * __xdata str);
