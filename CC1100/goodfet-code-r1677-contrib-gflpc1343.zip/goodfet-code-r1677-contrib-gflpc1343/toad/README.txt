TOAD: Totally Over-engineered Adapter/Detector

It's a ninja toad.

contributed by Michael Ossmann <mike@ossmann.com>

designed with KiCad: http://www.kicad-pcb.org

This is an experimental add-on module for the gflpc1343.  Firmware for this
board does not yet exist.

TOAD supports UART communication with configurable pinout and configurable
voltages including both TTL and RS-232 levels.  It also has some interesting
probing and sniffing capabilities.
