#ifndef _FONT_H
#define _FONT_H

extern __code const INT8U FontSystem6x8[];			
extern __code const INT8U Font8X8[];
extern __code const INT8U FontNew16X16[];
extern __code const INT8U FontNew8X16_Index[];
extern __code const INT8U WXL112X64[];

#endif
