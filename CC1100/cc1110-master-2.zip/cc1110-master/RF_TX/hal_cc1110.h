
#ifndef _HAL_CC1110_H_
#define _HAL_CC1110_H_

#include "ioCC1110.h"     // for IAR












#endif //_HAL_CC1110_H_
